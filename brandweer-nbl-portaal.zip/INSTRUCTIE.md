# Ploegportaal Brandweer Nieuw-Beijerland — livegang en onderhoud

Intern portaal met paraatheid (live uit Pre-Com) en uitrukcijfers (uit het opkomstregister).
Toegang via pincode. Adres na livegang: **https://hvanderee.github.io/brw-nbl-portaal/**

## Bestanden in dit pakket

| Bestand | Doel |
| --- | --- |
| `index.html` | De website zelf (logo en opmaak zitten erin). |
| `data.js` | Uitrukcijfers uit het opkomstregister (geaggregeerd, geen namen). |
| `bezetting.js` | Actuele bezetting/beschikbaarheid uit Pre-Com. Wordt automatisch bijgewerkt. |
| `precom_bezetting.py` | Script dat Pre-Com uitleest en `bezetting.js` schrijft. |
| `.github/workflows/bezetting.yml` | Laat GitHub dat script elk kwartier draaien. |
| `INSTRUCTIE.md` | Dit bestand. |

## Livegang (eenmalig)

1. Ga naar de repository **brw-nbl-portaal** op GitHub.
2. **Add file → Upload files.** Sleep alle bestanden erin **met behoud van de mappen**
   (dus ook de map `.github/workflows`). Het eenvoudigst: sleep de hele uitgepakte map.
3. Klik **Commit changes**.
4. **Settings → Pages:** Source = branch `main`, map `/ (root)`. (Staat waarschijnlijk al goed.)
5. Na een paar minuten staat de site online op het adres hierboven.

### Pre-Com-koppeling (eenmalig, al gedaan)

- **Settings → Secrets and variables → Actions** bevat `PRECOM_USER` en `PRECOM_PASS`.
- Wachtwoord gewijzigd? Werk `PRECOM_PASS` bij. Verder hoeft er niets te gebeuren.

## Bijwerken

- **Paraatheid:** gaat vanzelf. GitHub draait elk kwartier het script en ververst `bezetting.js`.
  Je computer hoeft niet aan te staan. Is de stand ouder dan een uur, dan toont het portaal "Niet actueel".
- **Uitrukcijfers:** vervang `data.js` na een nieuwe Excel-export van het opkomstregister.
  Lever de Excel aan, dan genereer ik een nieuwe `data.js`; die upload je over de oude heen.

## Pincode wijzigen

De pincode staat niet leesbaar in de code, alleen als versleutelde controle (SHA-256).
Een nieuwe code instellen: laat mij de nieuwe code omrekenen en de regel `PIN_HASH` in `index.html` vervangen.

## Belangrijk: privacy

- De repository is nu **openbaar**; iedereen die hem vindt, kan de bestanden lezen.
  Daarom staan er **alleen aantallen** op, **geen namen** van ploegleden.
- Wil je uitrukken **per persoon** aan de ploeg tonen, dan moet de site eerst afgeschermd worden
  (repository privé + echte login, bijvoorbeeld Cloudflare Access). Dat zetten we apart op.
- Bij spoed 112. Deze website is geen meldkanaal.
